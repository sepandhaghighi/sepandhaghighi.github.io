function [Vx,Vy] = opticalflow(images,alpha,iter)  

% Function For Applied Honor-Shunck Optical Flow Method

[height,width,frames]=size(images);   % Extracting Size Of Images Include Frames
  
Vx = zeros(height,width);    % Init Vx
Vy = zeros(height,width);    % Init Vy
for i=1:iter
for k = 1:frames-1  
    
  Ex = zeros(height-1,width-1,frames-1);   % Init Ex
  Ey = zeros(height-1,width-1,frames-1);   % Init Ey
  Et = zeros(height-1,width-1,frames-1);   % Init Et
 
    for x = 2:width-1  
      for y = 2:height-1 
          
           Ex(y,x,k) = (1/4)*(images(y+1,x+1,k)-images(y+1,x,k)+images(y,x+1,k)-images(y,x,k)+images(y+1,x+1,k+1)-images(y+1,x,k+1)+images(y,x+1,k+1)-images(y,x,k+1)); % Estimation Equation For Ex 

      
          Ey(y,x,k) = (1/4)*(images(y,x,k)-images(y+1,x,k)+images(y,x+1,k)-images(y+1,x+1,k)+images(y,x,k+1)-images(y+1,x,k+1)+images(y,x+1,k+1)-images(y+1,x+1,k+1));  % Estimation Equation For Ey

     
          Et(y,x,k) = (1/4)*(images(y+1,x,k+1)-images(y+1,x,k)+images(y,x,k+1)-images(y,x,k)+images(y+1,x+1,k+1)-images(y+1,x+1,k)+images(y,x+1,k+1)-images(y,x+1,k));   % Estimation Equation For Et
          
      end
    end
    
 

 
    for x = 2:width-1  
      for y = 2:height-1  
          
      
         
          
          Vxbar = (1/6)*(Vx(y-1,x)+Vx(y,x+1)+Vx(y+1,x)+Vx(y,x-1))+(1/12)*(Vx(y-1,x-1)+Vx(y-1,x+1)+Vx(y+1,x+1)+Vx(y+1,x-1));   % Estimation Equation For Vxbar
          Vybar = (1/6)*(Vy(y-1,x)+Vy(y,x+1)+Vy(y+1,x)+Vy(y,x-1))+(1/12)*(Vy(y-1,x-1)+Vy(y-1,x+1)+Vy(y+1,x+1)+Vy(y+1,x-1));   % Estimation Equation For Vybar
          State = (Ex(y,x,k)*Vxbar+Ey(y,x,k)*Vybar+Et(y,x,k))/(alpha^2 + Ex(y,x,k)^2 + Ey(y,x,k)^2);   % Temperory State  
          Vx(y,x) = Vxbar-Ex(y,x,k)*State;  % Estimate Vx By Gauss-Sidel Method
          Vy(y,x) = Vybar-Ey(y,x,k)*State;   % Estimate Vy By Gauss-Sidel Method
      end  
    end 
end
   
end  
  
  