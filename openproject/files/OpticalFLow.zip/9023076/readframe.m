function image = readframe( video , frame )
% readframe function for Reading Each Frame in Video


file=read(video);   % Convert Video Object To Numercial Matrix

image=file(:,:,:,frame);  % Extract Each Frame





end

