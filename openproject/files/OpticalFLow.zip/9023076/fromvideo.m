function y = fromvideo(videofile , color )

% Function For Reading A Video From File

    frame=1;  % Init Frame
    figure(1) % Figure 1
    while(1)

    tmp=readframe(videofile,frame);   % Read A Single Frame From video File by calling readframe.m
          
   if color==2   
    images(:,:,1,1) = tmp(:,:,1);
    images(:,:,2,1) = tmp(:,:,2);    % Extarct Each RGB Channel Information
    images(:,:,3,1) = tmp(:,:,3);
   else
       tmp=rgb2gray(tmp);
     images(:,:,1)=tmp;
   end
    
    if (size(images,4) >= 2 || size(images,3)>=2)      
      imshow(tmp);
      if color==2 
      image_r=images(:,:,1,:);
      image_g=images(:,:,2,:);
      image_b=images(:,:,3,:);
    % Calculation Vx And Vy For Each Of The Channel And Get Average   
      [Vx_r, Vy_r] = opticalflow(image_r, 100.0, 3);
      [Vx_g, Vy_g] = opticalflow(image_g, 100.0, 3);
      [Vx_b, Vy_b] = opticalflow(image_b, 100.0, 3);
      Vx=(Vx_r+Vx_g+Vx_b)/3;
      Vy=(Vy_r+Vy_g+Vy_b)/3;
      else
          [Vx,Vy]=opticalflow(images,100,2);
      end
      
      % Thresholding Noise Reduction 
      [ny,nx]=size(Vx);
      for y=1:ny-1
        for x=1:nx-1
          if  abs(Vx(y,x))<0.1
              Vx(y,x)=0;
          end           
          if abs(Vy(y,x))<0.1
              Vy(y,x)=0;
          end
        end
      end
      
      % Velocity Plot For Vx And Vy
      xgrid = 1:5:size(Vx,2);
      ygrid = 1:5:size(Vx,1);
      [xi,yi]=meshgrid(xgrid, ygrid); % Create Horizental And Vecrtical Grid
      Vxi = interp2(Vx, xi, yi);   % Interpolate In X Direction
      Vyi = interp2(Vy, xi, yi);    % Interpolate In Y Direction   
      hold on;            
      quiver(xgrid, ygrid, Vxi, Vyi, 2, 'r');      % Plot Velocity Vectors                        
      hold off;
      drawnow;          % Update The Figure Window
      a1 = [min(Vx(:)), max(Vx(:)), min(Vy(:)), max(Vy(:)), mean(Vx(:)), ...
        mean(Vy(:))];           
      drawnow;        
      fprintf('frame: %04d , Vx : %04d , Vy : %04d\n', frame , max(Vx(:)), max(Vy(:)));  % Printing Frame Number And Max(Vx) and Max(Vy)
    end 
    if color==2    
    images(:,:,:,2) = images(:,:,:,1); % Copy To Next Frame For Gray Scale Frame
    else 
        images(:,:,2)=images(:,:,1);    % Copy To Next Frame For RGB Frames
    end
    
    frame = frame + 1;            % Goto Next Frame
  end
end

