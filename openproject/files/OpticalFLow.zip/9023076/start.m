clear all
close all
clc
% Sepand Haghighi - 9023076
% Multimedia Final Project - Winter 2015
%--------------------------------------
% Question For Format Of Input
disp('Optical Flow  Based On Horn & Schunck Algorithm - 2015 Winter - Multimedia Final Project')
disp('Sepand Haghighi - 9023076')
query=input('Please Enter Input Format [1 : Webcam , 2 : Video File]  ');
color=input('Gray-Scale OR Color Video [ 1 : Gray-Scale , 2: RGB]');  % Get Input For Color Or Gray-Scale
if isempty(color)  || color ~=2  % Default Mode For Color Is GrayScale
   color=1; 
    
end


if isempty(query) || query~=2   % Default Mode
    query=1;
end

if query==1    % Webcam Mode
    
    webcam(color);  % Calling webcam
  
end  
  
if query==2   % Video File Mode
   ls         % List Of Files And Folder In Working Dir
   string=input('Please Enter File Address :  ');   %  Video File Address
   try
   videofile=VideoReader(string);   % Loading Video File
   
   fromvideo(videofile , color);           % Calling fromvideo.m
   
   catch
       error('Error In File Name')
   end
   
end

