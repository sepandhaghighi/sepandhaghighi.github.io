function y = webcam( color )
% Webcam Function For Get Input From Webcam And Analysis
images = [];   % Empty Matrix For Images

frame=1;       % Init Frame
a=imaqhwinfo('winvideo',1);    % Webcam Details

Device_Name = a.DeviceName     % Webcam Name

Supported_Formats=a.SupportedFormats    % Extracting Supported Formats By Webcam
index=input('Please Enter One Of This Resoultion :  ');   % Choosing One Of Supported Formats
if isempty(index)   % Default Mode
   index=1; 
end
res=Supported_Formats(1,index);    % Converting Cell to String
res=cell2mat(res);
if ~exist('video')       
    video = videoinput('winvideo', 1,res);  % Staring Getiing Video From Webcam
    set(video,'ReturnedColorSpace','rgb')   % Convert Webcam Format To RGB - Its For Some Webcam That Support YUV Foramts
    preview(video);                         % Preview Raw Image in webcam
end  
% Setting For Figures
  frame=1;
  figure(1);
  set(gcf, 'BackingStore', 'off');  
  figure(2);
  %set(gcf, 'toolbar', 'none');
  %set(gcf, 'MenuBar', 'none');
  set(gcf, 'BackingStore', 'off');
  figure(3);
  set(gcf, 'toolbar', 'none');
  set(gcf, 'MenuBar', 'none');  
  set(gcf, 'BackingStore', 'off');  

  while(1)   % Analysis Start

    tmp=getsnapshot(video);   % Get A Frame From Video

    
    tmp = imresize(tmp,0.5,'nearest');  %  Resizing Image By 0.5
    
 % Extarct Each RGB Channel Information
 if color==2 
    images(:,:,1,1) = tmp(:,:,1);     
    images(:,:,2,1) = tmp(:,:,2);
    images(:,:,3,1) = tmp(:,:,3);
 else
     tmp=rgb2gray(tmp);
     images(:,:,1)=tmp;
 end  
    
    if (size(images,4) >= 2 || size(images,3)>=2)
      set(0,'CurrentFigure',2)      
      imshow(tmp);
      if color==2 
          
      image_r=images(:,:,1,:);
      image_g=images(:,:,2,:);
      image_b=images(:,:,3,:);
      
   % Calculation Vx And Vy For Each Of The Channel And Get Average   
      [Vx_r, Vy_r] = opticalflow(image_r, 100, 2);
      [Vx_g, Vy_g] = opticalflow(image_g, 100, 2);
      [Vx_b, Vy_b] = opticalflow(image_b, 100, 2);
      Vx=(Vx_r+Vx_g+Vx_b)/3;
      Vy=(Vy_r+Vy_g+Vy_b)/3;
      else
          [Vx,Vy]=opticalflow(images,100,2);
      end
   % Thresholding Noise Reduction  
      [ny,nx]=size(Vx);
      for y=1:ny-1
        for x=1:nx-1
          if  abs(Vx(y,x))<0.1
              Vx(y,x)=0;
          end           
          if abs(Vy(y,x))<0.1
              Vy(y,x)=0;
          end
        end
      end
  
                                                                         
      xgrid = 1:5:size(Vx,2);       % Ploting Bar Diagram And Velocity Plot For Vx And Vy
      ygrid = 1:5:size(Vx,1);
      [xi,yi]=meshgrid(xgrid, ygrid);  % Create Horizental And Vertical Grid
      Vxi = interp2(Vx, xi, yi);       % 2D Interpolation In X And Y Direction
      Vyi = interp2(Vy, xi, yi);      
      hold on;            
      quiver(xgrid, ygrid, Vxi, Vyi, 2, 'r');      % Plot Velocity Vectors                        
      hold off;
      drawnow;
            
      set(0,'CurrentFigure',3)      
      a1 = [min(Vx(:)), max(Vx(:)), min(Vy(:)), max(Vy(:)), mean(Vx(:)), ...
        mean(Vy(:))];           
      bar(a1, 0.1, 'r');
      set(gca,'ylim',[-1 1]);      
      drawnow;    % Update The Figure Window     
      fprintf('frame: %04d , Vx : %04d , Vy : %04d\n', frame , max(Vx(:)), max(Vy(:)));   % Printing Frame Number And Max(Vx) and Max(Vy)
    end 
     if color ==2   
    images(:,:,:,2) = images(:,:,:,1);   % Copy To Next Frame For RGB Frame
     else  
        images(:,:,2)=images(:,:,1);     % Copy To Next Frame For Gray-Scale Frame
     end
    
    frame = frame + 1;          % Goto Next Frame
  end




